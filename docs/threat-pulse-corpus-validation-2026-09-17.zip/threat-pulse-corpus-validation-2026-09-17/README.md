# Corpus coverage validator

Matches a list of observables against a snapshot of the threat-pulse corpus and
reports, per observable type, how many were named in published reporting.

**It runs entirely on your machine.** There is no endpoint, no upload, no
telemetry, and no network call of any kind. The corpus travels to you in
`corpus-snapshot.json`; your values never leave. `validate.py` imports only the
Python standard library and touches only the files you name on the command line
— it is one file, and it is meant to be read before it is run.

Requires Python 3.9 or later. No installation.

```bash
python3 validate.py --input observables.csv --output results.csv --summary summary.json
```

Check the tool before you trust its output:

```bash
python3 test_validate.py
```

15 tests, shipped in this bundle, building their own corpus rather than reading
the snapshot — so they check the tool's behaviour independently of the data we
sent. One of them parses `validate.py` and asserts it imports no network,
subprocess or dynamic-execution module, so the central claim is checked
mechanically rather than by reading.

## Input

```csv
value,type,sample_id
evil.example.com,domain,S000001
203.0.113.10,ip,S000002
d41d8cd98f00b204e9800998ecf8427e,md5,S000003
CVE-2026-1234,cve,S000004
```

`type` and `sample_id` are optional; a plain one-value-per-line file works too.
When `type` is absent it is detected from the value's shape. When it is present
and disagrees with detection, both are reported in `type_supplied` and
`type_detected`, a `type_mismatch` note is added to `reason`, and the supplied
type is used for the lookup. A disagreement is a finding, not something to
resolve silently.

**A supplied type cannot defeat a safety skip.** The skip checks run against the
supplied type *and* the detected one, and a skip from either wins. A private
address labelled `domain` is skipped as `non_public_ip`, not looked up and
returned as a miss.

**Defanged input is accepted**, case-insensitively. `evil[.]com`, `evil(.)com`,
`evil[Dot]com`, `hxxp://`, `hxxps://` and combinations such as `hxxp[:]//` are
restored before anything else happens — the passes alternate until the value
stops changing, because the punctuation has to be restored before the scheme is
recognisable. Every change is named in the `normalization_applied` column —
`defang`, `defang_scheme`, `trailing_dot`. Nothing is altered silently.

**An unrecognised `type` is reported and discarded**, not trusted. A misspelled
or invented label previously became its own bucket in the per-type rates and
reached the lookup under a type that does not exist. The row now carries
`unknown_supplied_type:<label>` in `reason` and is classified by detection.

Do not send internal hostnames, private or reserved addresses, or live
unresolved indicators. The validator skips them and says so, but the safest
handling is not to put them in the file.

## Output

One row per submitted row, in `results.csv`, with `sample_id` preserved so you
can rejoin to your own records. `status` is one of:

| status | meaning |
|---|---|
| `hit` | a publisher named this value, and the row carries the citation |
| `miss` | this corpus, over the days it covers, does not name it |
| `excluded` | the pipeline saw it and ruled it out; `reason` gives the codes |
| `skipped` | not looked up at all; `reason` says why |
| `error` | the row could not be processed, **or the match cannot be cited** |

A hit that has no citation is returned as `error` with reason `missing_citation`,
never as a hit with an empty citation column. The specification requires a hit to
be citable; enforcing that in the reader rather than trusting the data is the
difference between a rule and an assumption.

Every input row produces exactly one output row. A value that raises while being
processed becomes an `error` row naming the exception — one bad row cannot end
the run and cost you the other results.

**`skipped` is never reported as `miss`.** A private address or an internal
hostname cannot appear in a corpus of published reporting, so answering "not
found" for one would be answering a question that was never asked. Skipped rows
are excluded from every denominator.

**`miss` is not a judgement that the value is benign.** It means this corpus,
over the days it covers, does not name it. Nothing more.

### Match methods

Only these three count toward the headline rate:

| method | relation |
|---|---|
| `exact` | the normalized values are identical |
| `parent_domain` | the submitted host is beneath a domain the corpus named |
| `same_host` | a submitted URL's host is a value the corpus named |

A submitted URL is tried **whole first**, so a full URL the corpus holds is
matched as `exact`. A trailing `/` is ignored on both sides. Only if that fails is
the URL reduced to its host and tried again, which is `same_host`. The two are
never conflated.

### Order of decision

1. an **exact** confirmation of the value, or of the whole URL → `hit`
2. an exclusion of the value, or of the whole URL → `excluded`
3. for a URL, a **same-host** confirmation → `hit`
4. for a URL, an exclusion of its host → `excluded`
5. a **parent** or **child** relation → `hit`
6. otherwise → `miss`

Exclusions are recorded per article. `excluded_editorial_section` means one
article mentioned the value outside its indicator section, and `publisher_domain`
means the value was that article's own publisher. So a direct confirmation
elsewhere outranks them. An exclusion still outranks a parent or child relation,
which is weaker than a statement about the value itself.

A value the corpus marked with a `benign_basis` is matched **only exactly**. The
basis is a brand apex such as `github.com`, a public resolver, or a registry
boundary. No `same_host`, `parent_domain` or `child_domain` relation passes through
it. Otherwise every URL on `github.com` and every host under
`login.microsoftonline.com` would count as a hit.

Parent matching **stops at the registrable domain**, using the Public Suffix
List embedded in the snapshot — the same list, by content digest, that the
reports were written against. `a.b.evil.com` finds `evil.com`; nothing finds
`co.uk` or `github.io`, because a registry belongs to no one and matching there
would tie unrelated tenants together.

A fourth relation is computed and reported separately:

| method | relation |
|---|---|
| `child_domain` | the corpus named something *beneath* the submitted domain |

It is real but weaker — submitting `example.com` and learning that
`cdn.example.com` was reported is not the same as `example.com` being reported.
It is **deliberately excluded from the headline rate**, because the decision
thresholds in your review were written against the three relations above, and
widening the definition would move the number against a rule set for something
narrower. `summary.json` carries both: `hit_rate` and
`hit_rate_including_child_domain`.

### Columns

`sample_id`, `value`, `type_supplied`, `type_detected`, `type_used`,
`normalized_value`, `normalization_applied`, `status`, `reason`, `match_method`,
`matched_value`,
`report_count`, `source_count`, `first_seen`, `last_seen`, `publication_date`,
`citation_url`, `citation_publisher`, `citation_count`, `publishers`, `action`,
`priority`,
`benign_basis`, `kev`, `kev_due_date`, `cvss_score`, `cvss_severity`,
`cvss_version`, `epss_score`, `epss_percentile`, `epss_date`, `cve_provenance`,
`cve_observed_on`.

- `report_count` — how many distinct daily reports named the value.
- `source_count` — how many distinct publishers named it. Expect `1` for almost
  every network indicator: publishers republish each other's CVE numbers, not
  each other's C2 infrastructure.
- `publishers` — all of them, semicolon-separated. **Read this before treating
  `source_count` above 1 as corroboration.** The count cannot tell independent
  reporting from republication, and in this corpus every network indicator with
  more than one publisher so far has been an aggregator carrying an original
  researcher's report — not two parties finding the same thing.
- `publication_date` — when the article was published, not when we collected it.
- `cve_provenance` — the URLs the KEV/CVSS/EPSS record was retrieved from, so a
  score can be traced rather than taken on trust.

## Rates

`summary.json` reports every rate **per observable type**, with the denominator
being values actually processed. Submitted, skipped, excluded and errored counts
stay visible beside it, so no number is reachable only by subtraction.

`network_combined` covers domain, ip, url and hash types together. CVEs are
never folded into it: the two populations behave differently, and a combined
rate would hide exactly the difference this exercise is measuring.

## What this measures, and what it does not

This is **current-corpus coverage**. The corpus holds only the days it has
collected, and the input carries no alert timestamps, so this cannot say what
the service would have known at the time of each alert.

It is **not** detection performance and **not** decision impact. A hit means a
publisher named the value and here is the citation. Whether that would have
changed an investigation is a judgement only an analyst reading the hits against
the original alerts can make.

Citations are checked for existence, not reachability: the validator does not
open them, because it does not open anything.

## Integrity

**The validator recomputes `corpus_version` from the snapshot's own contents
before it does anything else, and refuses to run if it does not match.** The
digest covers the values, the excluded set, the CVE records **and the full
Public Suffix List rules** — not merely the version string that names them.
Hashing only the version would leave the boundary rules editable while the check
still passed, and those rules are what decide where a parent-domain match stops:
remove a registry from the list and unrelated tenants beneath it begin matching
each other. It also checks that the number of values the snapshot claims to hold
is the number it carries. A truncated, partially written or edited snapshot is rejected rather
than quietly producing results that look ordinary.

This is an integrity check, not an authenticity one. It proves the file is
internally consistent and unaltered since it was built; it cannot prove who
built it. **A SHA-256 that arrives in the same message as the file proves
neither** — if origin matters to you, ask us for the digest over a channel the
file did not travel on, or ask for a detached signature and we will arrange a
key exchange.

## Reproducibility

`corpus_version` appears in `summary.json`, alongside
`corpus_version_recomputed`, and identifies the corpus state. The same version
over the same input produces the same result — it is a digest of the values,
counts, citations, excluded set and boundary rules, and deliberately not of the
time the snapshot was built.

`days_with_source_failures` lists any day in the window where a source could not
be read. A value absent because its publisher was unreachable that day is not
the same as a value nobody reported, and this is what says which days had a gap.

## What is in the snapshot

Confirmed indicators and CVE identifiers, with the publisher, article title,
article URL and publication date for each; the KEV/CVSS/EPSS record for each CVE
with its retrieval provenance; the excluded values and their reason codes; the
per-day source-failure record; and the Public Suffix List rules.

Article bodies are **not** included. They are 26 publishers' text, several under
redistribution terms, and no match needs them.
